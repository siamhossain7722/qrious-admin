<?php
/**
 * SIAM HOSSAIN - FULL STACK DEVELOPER PORTFOLIO
 * WordPress Page Template
 */

if (!defined('ABSPATH')) {
    exit;
}

$dev_name   = get_option('siam_portfolio_name', 'Siam Hossain');
$dev_role   = get_option('siam_portfolio_role', 'Full Stack Developer');
$dev_email  = get_option('siam_portfolio_email', 'mdsiamh77@gmail.com');
$dev_phone  = get_option('siam_portfolio_phone', '+880 1xxx-xxxxxx');
$avatar_url = get_option('siam_portfolio_avatar_url');

if (empty($avatar_url)) {
    $avatar_url = SIAM_PORTFOLIO_URL . 'assets/images/Profile.png';
}

$about_img_url = SIAM_PORTFOLIO_URL . 'assets/images/Profile2.png';
$logo_url      = SIAM_PORTFOLIO_URL . 'assets/images/logo.png';
$favicon_url   = SIAM_PORTFOLIO_URL . 'assets/images/favicon.png';

// Projects
$p1_url = SIAM_PORTFOLIO_URL . 'assets/images/projects/snapbook.png';
$p2_url = SIAM_PORTFOLIO_URL . 'assets/images/projects/review.png';
$p3_url = SIAM_PORTFOLIO_URL . 'assets/images/projects/eventify.png';
$p4_url = SIAM_PORTFOLIO_URL . 'assets/images/projects/cpl.png';

// Certificates
$c_uap     = SIAM_PORTFOLIO_URL . 'assets/images/certificates/UAP.jpg';
$c_phitron = SIAM_PORTFOLIO_URL . 'assets/images/certificates/Certificate_Phitron.jpg';
$c_ua      = SIAM_PORTFOLIO_URL . 'assets/images/certificates/UA.jpg';
$c_gbs     = SIAM_PORTFOLIO_URL . 'assets/images/certificates/GBS.jpg';
$c_claude  = SIAM_PORTFOLIO_URL . 'assets/images/certificates/Certificate_Claude.jpg';
$c_food    = SIAM_PORTFOLIO_URL . 'assets/images/certificates/food_safty.jpg';

// Blog images
$b1_url = SIAM_PORTFOLIO_URL . 'assets/images/blog-1.jpg';
$b2_url = SIAM_PORTFOLIO_URL . 'assets/images/blog-2.jpg';
$b3_url = SIAM_PORTFOLIO_URL . 'assets/images/blog-3.jpg';

$resume_url = 'https://drive.google.com/file/d/1Rg-xNQwb2LJD5uCNRTVrWT2anLt7XZPr/view?usp=sharing';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?> data-theme="dark">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo esc_html($dev_name); ?> | <?php echo esc_html($dev_role); ?></title>
    
    <!-- Instant Theme Initializer (prevents FOUC) -->
    <script>
        (function() {
            var theme = localStorage.getItem('siam_portfolio_theme') || 'dark';
            document.documentElement.setAttribute('data-theme', theme);
        })();
    </script>
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&family=Rajdhani:wght@500;600;700&display=swap" rel="stylesheet">
    
    <!-- Devicon Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/devicons/devicon@latest/devicon.min.css">

    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo esc_url($favicon_url); ?>">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo esc_url(SIAM_PORTFOLIO_URL . 'assets/css/style.css?v=' . SIAM_PORTFOLIO_VERSION); ?>">

    <style>
        /* Overrides to ensure complete full-bleed canvas across any WordPress theme */
        html, body {
            margin: 0 !important;
            padding: 0 !important;
            width: 100% !important;
            max-width: 100% !important;
            overflow-x: hidden !important;
        }
        #wpadminbar {
            opacity: 0.85;
            transition: opacity 0.2s;
        }
        #wpadminbar:hover {
            opacity: 1;
        }
        body.admin-bar .main-header {
            top: 32px;
        }
        @media screen and (max-width: 782px) {
            body.admin-bar .main-header {
                top: 46px;
            }
        }
    </style>

    <?php wp_head(); ?>
</head>
<body <?php body_class('siam-portfolio-body'); ?>>

    <!-- Toast Notification Container -->
    <div id="toast-container" class="toast-container"></div>

    <!-- Offcanvas Navigation Sidebar -->
    <div id="offcanvas-overlay" class="offcanvas-overlay"></div>
    <aside id="offcanvas-sidebar" class="offcanvas-sidebar">
        <div class="offcanvas-header">
            <a href="#" class="brand-logo">
                <img src="<?php echo esc_url($logo_url); ?>" alt="Siam Logo" class="brand-logo-img">
                <span>Siam<span class="logo-dot">.</span>dev</span>
            </a>
            <button id="offcanvas-close" class="close-btn" aria-label="Close menu">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
        <div class="offcanvas-body">
            <div class="offcanvas-profile">
                <div class="profile-img-wrap">
                    <img src="<?php echo esc_url($avatar_url); ?>" alt="<?php echo esc_attr($dev_name); ?>" class="sidebar-avatar">
                    <span class="status-indicator" title="Open to work"></span>
                </div>
                <h4 class="profile-name"><?php echo esc_html($dev_name); ?></h4>
                <p class="profile-role"><?php echo esc_html($dev_role); ?></p>
                <div class="profile-badges">
                    <span class="mini-badge">Django</span>
                    <span class="mini-badge">React</span>
                    <span class="mini-badge">Python</span>
                </div>
            </div>

            <nav class="offcanvas-nav">
                <ul>
                    <li><a href="#home" class="nav-link active"><i class="fa-solid fa-house"></i> Home</a></li>
                    <li><a href="#about" class="nav-link"><i class="fa-solid fa-user"></i> About Me</a></li>
                    <li><a href="#services" class="nav-link"><i class="fa-solid fa-layer-group"></i> Services</a></li>
                    <li><a href="#skills" class="nav-link"><i class="fa-solid fa-code"></i> Skills</a></li>
                    <li><a href="#experience" class="nav-link"><i class="fa-solid fa-briefcase"></i> Experience & Education</a></li>
                    <li><a href="#portfolio" class="nav-link"><i class="fa-solid fa-folder-open"></i> Projects</a></li>
                    <li><a href="#achievements" class="nav-link"><i class="fa-solid fa-award"></i> Achievements</a></li>
                    <li><a href="#testimonials" class="nav-link"><i class="fa-solid fa-comments"></i> Reviews</a></li>
                    <li><a href="#blog" class="nav-link"><i class="fa-solid fa-newspaper"></i> Articles</a></li>
                    <li><a href="#contact" class="nav-link"><i class="fa-solid fa-paper-plane"></i> Contact</a></li>
                </ul>
            </nav>

            <div style="margin: 20px 0;">
                <a href="<?php echo esc_url($resume_url); ?>" target="_blank" class="btn btn-primary btn-round btn-full">
                    <i class="fa-solid fa-file-arrow-down"></i>
                    <span>Download CV</span>
                </a>
            </div>

            <div class="offcanvas-contact-info">
                <h5>Get In Touch</h5>
                <p><i class="fa-solid fa-envelope"></i> <?php echo esc_html($dev_email); ?></p>
                <p><i class="fa-solid fa-location-dot"></i> Bangladesh (Global Remote)</p>
            </div>

            <div class="offcanvas-socials">
                <a href="https://github.com/siamhossain7722" target="_blank" aria-label="GitHub"><i class="fa-brands fa-github"></i></a>
                <a href="https://www.linkedin.com/in/siamhossain7722/" target="_blank" aria-label="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
                <a href="https://www.facebook.com/siamhossain7722/" target="_blank" aria-label="Facebook"><i class="fa-brands fa-facebook"></i></a>
            </div>
        </div>
    </aside>

    <!-- Header / Navbar -->
    <header id="main-header" class="main-header">
        <div class="header-container container">
            <!-- Brand Logo -->
            <a href="#" class="brand-logo">
                <img src="<?php echo esc_url($logo_url); ?>" alt="Siam Logo" class="brand-logo-img">
                <span>Siam<span class="logo-dot">.</span>dev</span>
            </a>

            <!-- Desktop Menu -->
            <nav class="desktop-nav">
                <ul class="nav-list">
                    <li><a href="#home" class="nav-link active">Home</a></li>
                    <li><a href="#about" class="nav-link">About</a></li>
                    <li><a href="#services" class="nav-link">Services</a></li>
                    <li><a href="#skills" class="nav-link">Skills</a></li>
                    <li><a href="#experience" class="nav-link">Experience</a></li>
                    <li><a href="#portfolio" class="nav-link">Projects</a></li>
                    <li><a href="#achievements" class="nav-link">Achievements</a></li>
                    <li><a href="#testimonials" class="nav-link">Reviews</a></li>
                    <li><a href="#blog" class="nav-link">Articles</a></li>
                    <li><a href="#contact" class="nav-link">Contact</a></li>
                </ul>
            </nav>

            <!-- Header Actions -->
            <div class="header-actions">
                <!-- Theme Switcher -->
                <button id="theme-toggle" class="theme-toggle-btn" aria-label="Toggle theme">
                    <i class="fa-solid fa-sun icon-sun"></i>
                    <i class="fa-solid fa-moon icon-moon"></i>
                </button>

                <!-- CV Download Link -->
                <a href="<?php echo esc_url($resume_url); ?>" target="_blank" class="btn btn-secondary btn-round d-none-mobile">
                    <i class="fa-solid fa-file-pdf"></i>
                    <span>CV</span>
                </a>

                <!-- Header CTA Button -->
                <a href="#contact" class="btn btn-primary btn-round header-cta d-none-mobile">
                    <span>Hire Me</span>
                    <i class="fa-solid fa-arrow-right"></i>
                </a>

                <!-- Hamburger Menu Button -->
                <button id="hamburger-btn" class="hamburger-btn" aria-label="Open mobile menu">
                    <span class="bar bar-1"></span>
                    <span class="bar bar-2"></span>
                    <span class="bar bar-3"></span>
                </button>
            </div>
        </div>
    </header>

    <main>
        <!-- Hero Section -->
        <section id="home" class="hero-section">
            <div class="container hero-container">
                <div class="hero-grid">
                    <!-- Left Column: Content -->
                    <div class="hero-content">
                        <div class="hero-badge">
                            <span class="badge-dot"></span>
                            <span>OPEN TO WORK & AVAILABLE FOR PROJECTS</span>
                        </div>
                        <h1 class="hero-title">
                            Hello, I'm <span class="highlight-text"><?php echo esc_html($dev_name); ?></span>
                            <br>
                            <span class="typed-wrapper">
                                a <span id="typewriter" class="gradient-text"></span><span class="cursor">&nbsp;</span>
                            </span>
                        </h1>
                        <p class="hero-description">
                            I specialize in Django, React and JavaScript. I like building clean, fast, and scalable web applications with a strong focus on user experience, backend performance, and architectural quality.
                        </p>

                        <!-- Tech Pills Strip -->
                        <div class="hero-tech-strip">
                            <span class="tech-tag"><i class="devicon-django-plain colored"></i> Django</span>
                            <span class="tech-tag"><i class="devicon-react-original colored"></i> React</span>
                            <span class="tech-tag"><i class="devicon-python-plain colored"></i> Python</span>
                            <span class="tech-tag"><i class="devicon-postgresql-plain colored"></i> PostgreSQL</span>
                            <span class="tech-tag"><i class="devicon-nextjs-plain"></i> Next.js</span>
                            <span class="tech-tag"><i class="devicon-fastapi-plain colored"></i> FastAPI</span>
                        </div>

                        <!-- CTA Buttons -->
                        <div class="hero-buttons">
                            <a href="#portfolio" class="btn btn-primary btn-round btn-icon-flip">
                                <span class="btn-text">View Projects</span>
                                <span class="icon-wrap">
                                    <i class="fa-solid fa-arrow-right icon-main"></i>
                                    <i class="fa-solid fa-arrow-right icon-alt"></i>
                                </span>
                            </a>
                            <a href="<?php echo esc_url($resume_url); ?>" target="_blank" class="btn btn-secondary btn-round">
                                <i class="fa-solid fa-file-pdf"></i>
                                <span>Download CV</span>
                            </a>
                            <a href="#contact" class="btn btn-secondary btn-round">
                                <i class="fa-regular fa-paper-plane"></i>
                                <span>Get In Touch</span>
                            </a>
                        </div>

                        <!-- Social Links Row -->
                        <div class="hero-social-row">
                            <span class="social-label">Find Me On:</span>
                            <div class="social-links">
                                <a href="https://github.com/siamhossain7722" target="_blank" class="social-icon" aria-label="GitHub"><i class="fa-brands fa-github"></i></a>
                                <a href="https://www.linkedin.com/in/siamhossain7722/" target="_blank" class="social-icon" aria-label="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
                                <a href="https://www.facebook.com/siamhossain7722/" target="_blank" class="social-icon" aria-label="Facebook"><i class="fa-brands fa-facebook"></i></a>
                            </div>
                        </div>
                    </div>

                    <!-- Right Column: Visual Showcase -->
                    <div class="hero-visual">
                        <div class="kinetic-text kinetic-text-1">FULL STACK DEVELOPER</div>
                        <div class="kinetic-text kinetic-text-2">DJANGO & REACT EXPERT</div>

                        <!-- Image Showcase Card -->
                        <div class="hero-image-wrapper">
                            <div class="hero-glow-effect"></div>
                            <div class="image-frame">
                                <img src="<?php echo esc_url($avatar_url); ?>" alt="<?php echo esc_attr($dev_name); ?>" class="hero-img">
                            </div>

                            <!-- Floating Stat Card 1 -->
                            <div class="floating-badge badge-exp">
                                <div class="badge-icon"><i class="fa-solid fa-award"></i></div>
                                <div class="badge-details">
                                    <span class="badge-num">2+</span>
                                    <span class="badge-txt">Years Experience</span>
                                </div>
                            </div>

                            <!-- Floating Stat Card 2 -->
                            <div class="floating-badge badge-completed">
                                <div class="badge-icon"><i class="fa-solid fa-code-merge"></i></div>
                                <div class="badge-details">
                                    <span class="badge-num">10+</span>
                                    <span class="badge-txt">Projects Shipped</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- About Me Section -->
        <section id="about" class="about-section section-gap">
            <div class="container">
                <div class="section-header text-center">
                    <span class="section-tag">GET TO KNOW ME</span>
                    <h2 class="section-title">About Me</h2>
                    <p class="section-subtitle">Bridging robust backend engineering with intuitive, responsive modern frontends and digital growth strategy.</p>
                </div>

                <div class="about-grid">
                    <!-- Left Column: Photo Showcase -->
                    <div class="about-image-wrapper">
                        <div class="about-img-frame">
                            <img src="<?php echo esc_url($about_img_url); ?>" alt="<?php echo esc_attr($dev_name); ?> Full Stack Developer" class="about-img">
                        </div>

                        <div class="about-floating-badge">
                            <div class="about-badge-icon">
                                <i class="fa-solid fa-laptop-code"></i>
                            </div>
                            <div class="about-badge-text">
                                <h5>Software Developer</h5>
                                <p>Digital Marketing & Growth</p>
                            </div>
                        </div>
                    </div>

                    <!-- Right Column: Biography & Details -->
                    <div class="about-content">
                        <div class="about-paragraphs">
                            <p>
                                I am a web developer specializing in building scalable backend systems with Django and creating clean, responsive user interfaces. I enjoy turning complex requirements into reliable, maintainable, and user-friendly web applications.
                            </p>
                            <p>
                                My development experience includes Django, Django REST Framework, React, Next.js, JavaScript, TypeScript, Python, FastAPI, PostgreSQL, and modern frontend technologies. I focus on building secure APIs, database-driven applications, responsive interfaces, and practical solutions that perform well in real-world environments.
                            </p>
                            <p>
                                Alongside software development, I have experience in digital marketing, including Google Ads, Meta Ads, product marketing, social media content, content writing, and website management with WordPress. I also explore AI agent development and implementation to create smarter and more efficient digital solutions.
                            </p>
                        </div>

                        <div class="about-info-grid">
                            <div class="about-info-item">
                                <span class="about-info-label">Name</span>
                                <span class="about-info-val"><?php echo esc_html($dev_name); ?></span>
                            </div>
                            <div class="about-info-item">
                                <span class="about-info-label">Location</span>
                                <span class="about-info-val">Bangladesh (Global Remote)</span>
                            </div>
                            <div class="about-info-item">
                                <span class="about-info-label">Availability</span>
                                <span class="about-info-val" style="color: #10b981;"><i class="fa-solid fa-circle" style="font-size: 0.65rem;"></i> Open to Work</span>
                            </div>
                            <div class="about-info-item">
                                <span class="about-info-label">Email</span>
                                <span class="about-info-val"><a href="mailto:<?php echo esc_attr($dev_email); ?>"><?php echo esc_html($dev_email); ?></a></span>
                            </div>
                            <div class="about-info-item">
                                <span class="about-info-label">Education</span>
                                <span class="about-info-val">B.Sc. in Computer Science (UAP)</span>
                            </div>
                            <div class="about-info-item">
                                <span class="about-info-label">Specialization</span>
                                <span class="about-info-val">Django, React, APIs & AI Agents</span>
                            </div>
                        </div>

                        <div class="about-actions">
                            <a href="<?php echo esc_url($resume_url); ?>" target="_blank" class="btn btn-primary btn-round btn-icon-flip">
                                <span class="btn-text">Download Full CV</span>
                                <span class="icon-wrap">
                                    <i class="fa-solid fa-file-arrow-down icon-main"></i>
                                    <i class="fa-solid fa-file-arrow-down icon-alt"></i>
                                </span>
                            </a>
                            <a href="#contact" class="btn btn-secondary btn-round">
                                <span>Get In Touch</span>
                                <i class="fa-solid fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Core Capabilities / Services 4-Column Section -->
        <section id="services" class="services-area section-gap">
            <div class="container">
                <div class="section-header text-center">
                    <span class="section-tag">SPECIALIZED EXPERTISE</span>
                    <h2 class="section-title">What I Bring To The Table</h2>
                    <p class="section-subtitle">Delivering high-performance backend architecture, clean frontend engineering, and digital growth results.</p>
                </div>

                <div class="services-grid">
                    <!-- Service 1 -->
                    <div class="service-card" data-service-id="1">
                        <div class="service-card-top">
                            <div class="service-icon-box">
                                <i class="fa-solid fa-server"></i>
                            </div>
                            <span class="project-count">Django & DRF</span>
                        </div>
                        <h3 class="service-title">Backend & REST APIs</h3>
                        <p class="service-desc">Scalable, secure backend development using Django, Django REST Framework, Python, and FastAPI with robust database design and token authentication.</p>
                        <a href="javascript:void(0)" class="service-more-link" onclick="openServiceModal(1)">
                            <span>Explore Details</span>
                            <i class="fa-solid fa-arrow-right"></i>
                        </a>
                    </div>

                    <!-- Service 2 -->
                    <div class="service-card" data-service-id="2">
                        <div class="service-card-top">
                            <div class="service-icon-box">
                                <i class="fa-brands fa-react"></i>
                            </div>
                            <span class="project-count">React & Next.js</span>
                        </div>
                        <h3 class="service-title">Full-Stack Web Apps</h3>
                        <p class="service-desc">End-to-end interactive web applications built with React, Next.js, TypeScript, and modern state architectures delivering smooth, responsive user experiences.</p>
                        <a href="javascript:void(0)" class="service-more-link" onclick="openServiceModal(2)">
                            <span>Explore Details</span>
                            <i class="fa-solid fa-arrow-right"></i>
                        </a>
                    </div>

                    <!-- Service 3 -->
                    <div class="service-card" data-service-id="3">
                        <div class="service-card-top">
                            <div class="service-icon-box">
                                <i class="fa-solid fa-chart-line"></i>
                            </div>
                            <span class="project-count">Meta & Google Ads</span>
                        </div>
                        <h3 class="service-title">Digital Marketing & Growth</h3>
                        <p class="service-desc">Strategic digital campaigns across Meta Ads, Google Ads, targeted product marketing, copywriting, and analytics to drive user acquisition and sales.</p>
                        <a href="javascript:void(0)" class="service-more-link" onclick="openServiceModal(3)">
                            <span>Explore Details</span>
                            <i class="fa-solid fa-arrow-right"></i>
                        </a>
                    </div>

                    <!-- Service 4 -->
                    <div class="service-card" data-service-id="4">
                        <div class="service-card-top">
                            <div class="service-icon-box">
                                <i class="fa-solid fa-robot"></i>
                            </div>
                            <span class="project-count">WordPress & AI</span>
                        </div>
                        <h3 class="service-title">CMS & AI Agent Workflows</h3>
                        <p class="service-desc">Comprehensive WordPress website administration, speed optimization, and cutting-edge AI agent integrations to automate workflows and elevate engagement.</p>
                        <a href="javascript:void(0)" class="service-more-link" onclick="openServiceModal(4)">
                            <span>Explore Details</span>
                            <i class="fa-solid fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Stats & Impact Counters Section -->
        <section class="counter-section">
            <div class="container">
                <div class="counter-wrapper glass-panel">
                    <div class="counter-left">
                        <div class="counter-highlight-box">
                            <div class="highlight-number-wrap">
                                <span class="counter-val highlight-num" data-target="2">0</span>
                                <span class="highlight-plus">+</span>
                            </div>
                            <h3 class="highlight-title">Years of Practical <br>Development</h3>
                        </div>
                        <p class="highlight-para">Building scalable web applications, secure APIs, and responsive digital products for businesses and startups globally.</p>
                    </div>

                    <div class="counter-right-grid">
                        <div class="metric-card">
                            <div class="metric-number-wrap">
                                <span class="counter-val" data-target="10">0</span>
                                <span class="metric-suffix">+</span>
                            </div>
                            <p class="metric-label">Completed Projects</p>
                        </div>

                        <div class="metric-card">
                            <div class="metric-number-wrap">
                                <span class="counter-val" data-target="5">0</span>
                                <span class="metric-suffix">+</span>
                            </div>
                            <p class="metric-label">Core Tech Stacks</p>
                        </div>

                        <div class="metric-card">
                            <div class="metric-number-wrap">
                                <span class="counter-val" data-target="6">0</span>
                                <span class="metric-suffix">+</span>
                            </div>
                            <p class="metric-label">Honors & Certifications</p>
                        </div>

                        <div class="metric-card">
                            <div class="metric-number-wrap">
                                <span class="counter-val" data-target="100">0</span>
                                <span class="metric-suffix">%</span>
                            </div>
                            <p class="metric-label">Commitment to Quality</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Technical Mastery & Skills Section -->
        <section id="skills" class="skills-section section-gap">
            <div class="container">
                <div class="section-header text-center">
                    <span class="section-tag">PROFICIENCY & STACK</span>
                    <h2 class="section-title">Technical Mastery</h2>
                    <p class="section-subtitle">A balanced fusion of backend database architectures, modern frontend frameworks, and digital marketing tools.</p>
                </div>

                <div class="skills-grid">
                    <!-- Column 1: Backend, APIs & Databases -->
                    <div class="skill-category-card">
                        <div class="category-header">
                            <div class="cat-icon"><i class="fa-solid fa-server"></i></div>
                            <div>
                                <h3 class="cat-title">Backend & Database Engineering</h3>
                                <p class="cat-desc">APIs, data models & scalable server architecture</p>
                            </div>
                        </div>

                        <div class="skill-bars">
                            <div class="skill-bar-item">
                                <div class="skill-info">
                                    <span class="skill-name">Django & Django REST Framework (DRF)</span>
                                    <span class="skill-percent">95%</span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" data-progress="95"></div>
                                </div>
                            </div>

                            <div class="skill-bar-item">
                                <div class="skill-info">
                                    <span class="skill-name">Python & FastAPI</span>
                                    <span class="skill-percent">90%</span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" data-progress="90"></div>
                                </div>
                            </div>

                            <div class="skill-bar-item">
                                <div class="skill-info">
                                    <span class="skill-name">PostgreSQL, MySQL & SQLite</span>
                                    <span class="skill-percent">92%</span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" data-progress="92"></div>
                                </div>
                            </div>

                            <div class="skill-bar-item">
                                <div class="skill-info">
                                    <span class="skill-name">Node.js & Express.js</span>
                                    <span class="skill-percent">82%</span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" data-progress="82"></div>
                                </div>
                            </div>

                            <div class="skill-bar-item">
                                <div class="skill-info">
                                    <span class="skill-name">Supabase & RESTful API Architecture</span>
                                    <span class="skill-percent">90%</span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" data-progress="90"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Column 2: Frontend Engineering & UI -->
                    <div class="skill-category-card">
                        <div class="category-header">
                            <div class="cat-icon"><i class="fa-solid fa-code"></i></div>
                            <div>
                                <h3 class="cat-title">Frontend Engineering & UI</h3>
                                <p class="cat-desc">Reactive web interfaces & responsive design</p>
                            </div>
                        </div>

                        <div class="skill-bars">
                            <div class="skill-bar-item">
                                <div class="skill-info">
                                    <span class="skill-name">React & Next.js</span>
                                    <span class="skill-percent">92%</span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" data-progress="92"></div>
                                </div>
                            </div>

                            <div class="skill-bar-item">
                                <div class="skill-info">
                                    <span class="skill-name">JavaScript & TypeScript</span>
                                    <span class="skill-percent">90%</span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" data-progress="90"></div>
                                </div>
                            </div>

                            <div class="skill-bar-item">
                                <div class="skill-info">
                                    <span class="skill-name">HTML5 & CSS3 Responsive Layouts</span>
                                    <span class="skill-percent">96%</span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" data-progress="96"></div>
                                </div>
                            </div>

                            <div class="skill-bar-item">
                                <div class="skill-info">
                                    <span class="skill-name">Tailwind CSS & Bootstrap</span>
                                    <span class="skill-percent">92%</span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" data-progress="92"></div>
                                </div>
                            </div>

                            <div class="skill-bar-item">
                                <div class="skill-info">
                                    <span class="skill-name">Digital Marketing, SEO & WordPress</span>
                                    <span class="skill-percent">88%</span>
                                </div>
                                <div class="progress-track">
                                    <div class="progress-fill" data-progress="88"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Complete Tech Stack Cloud with Real Devicon Badges -->
                <div class="tech-badge-cloud">
                    <span class="cloud-pill"><i class="devicon-python-plain colored"></i> Python</span>
                    <span class="cloud-pill"><i class="devicon-django-plain colored"></i> Django</span>
                    <span class="cloud-pill"><i class="devicon-fastapi-plain colored"></i> FastAPI</span>
                    <span class="cloud-pill"><i class="devicon-react-original colored"></i> React</span>
                    <span class="cloud-pill"><i class="devicon-nextjs-plain"></i> Next.js</span>
                    <span class="cloud-pill"><i class="devicon-javascript-plain colored"></i> JavaScript</span>
                    <span class="cloud-pill"><i class="devicon-typescript-plain colored"></i> TypeScript</span>
                    <span class="cloud-pill"><i class="devicon-postgresql-plain colored"></i> PostgreSQL</span>
                    <span class="cloud-pill"><i class="devicon-mysql-plain colored"></i> MySQL</span>
                    <span class="cloud-pill"><i class="devicon-sqlite-plain colored"></i> SQLite</span>
                    <span class="cloud-pill"><i class="devicon-supabase-plain colored"></i> Supabase</span>
                    <span class="cloud-pill"><i class="devicon-nodejs-plain colored"></i> Node.js</span>
                    <span class="cloud-pill"><i class="devicon-express-original colored"></i> Express.js</span>
                    <span class="cloud-pill"><i class="devicon-html5-plain colored"></i> HTML5</span>
                    <span class="cloud-pill"><i class="devicon-css3-plain colored"></i> CSS3</span>
                    <span class="cloud-pill"><i class="devicon-tailwindcss-original colored"></i> Tailwind CSS</span>
                    <span class="cloud-pill"><i class="devicon-bootstrap-plain colored"></i> Bootstrap</span>
                    <span class="cloud-pill"><i class="devicon-git-plain colored"></i> Git</span>
                    <span class="cloud-pill"><i class="devicon-linux-plain colored"></i> Linux</span>
                    <span class="cloud-pill"><i class="devicon-docker-plain colored"></i> Docker</span>
                    <span class="cloud-pill"><i class="devicon-vercel-original colored"></i> Vercel</span>
                    <span class="cloud-pill"><i class="fa-brands fa-wordpress text-blue"></i> WordPress</span>
                </div>
            </div>
        </section>

        <!-- Career & Education Experience Timeline -->
        <section id="experience" class="experience-section section-gap">
            <div class="container">
                <div class="section-header text-center">
                    <span class="section-tag">TRACK RECORD</span>
                    <h2 class="section-title">Experience & Education</h2>
                    <p class="section-subtitle">Hands-on software development roles alongside rigorous academic degrees and training.</p>
                </div>

                <div class="journey-grid">
                    <!-- Column 1: Professional Experience -->
                    <div class="journey-column">
                        <div class="journey-heading">
                            <i class="fa-solid fa-briefcase"></i>
                            <h3>Professional Experience</h3>
                        </div>

                        <div class="timeline-items">
                            <!-- Exp 1: BooleanForce -->
                            <div class="timeline-card">
                                <div class="timeline-badge">2026 – Present</div>
                                <h4 class="role-title">Full Stack Developer</h4>
                                <h5 class="company-name">BooleanForce &bull; Full-Stack Role</h5>
                                <p class="role-desc">Working on full-stack web applications, fixing bugs, developing new features, and refactoring existing Django projects for performance and scalability.</p>
                                <div class="timeline-skills-list">
                                    <span class="timeline-skill-pill">Python</span>
                                    <span class="timeline-skill-pill">Django</span>
                                    <span class="timeline-skill-pill">Next.js</span>
                                    <span class="timeline-skill-pill">TypeScript</span>
                                    <span class="timeline-skill-pill">React</span>
                                    <span class="timeline-skill-pill">REST API</span>
                                    <span class="timeline-skill-pill">PostgreSQL</span>
                                    <span class="timeline-skill-pill">Deployment</span>
                                </div>
                            </div>

                            <!-- Exp 2: FlyRank AI -->
                            <div class="timeline-card">
                                <div class="timeline-badge">2026 – Present</div>
                                <h4 class="role-title">Backend Developer Intern</h4>
                                <h5 class="company-name">FlyRank AI &bull; Backend Engineering</h5>
                                <p class="role-desc">Building custom Django and Express.js web applications, REST APIs, interactive dashboards, and business-focused solutions.</p>
                                <div class="timeline-skills-list">
                                    <span class="timeline-skill-pill">Django</span>
                                    <span class="timeline-skill-pill">Express.js</span>
                                    <span class="timeline-skill-pill">DRF</span>
                                    <span class="timeline-skill-pill">REST API</span>
                                    <span class="timeline-skill-pill">PostgreSQL</span>
                                </div>
                            </div>

                            <!-- Exp 3: MB "Global Altajir Business & IT Services" -->
                            <div class="timeline-card">
                                <div class="timeline-badge">Jan 2026 – Aug 2026</div>
                                <h4 class="role-title">Full Stack Developer & Digital Marketing Manager</h4>
                                <h5 class="company-name">MB "Global Altajir Business & IT Services" &bull; Vilnius, Lithuania (Remote)</h5>
                                <p class="role-desc">Developed and maintained scalable web applications using Django, MERN Stack, React, and Node.js. Built responsive, user-friendly websites following modern UI/UX practices while driving digital marketing campaigns and online business growth.</p>
                                <div class="timeline-skills-list">
                                    <span class="timeline-skill-pill">Django</span>
                                    <span class="timeline-skill-pill">MERN Stack</span>
                                    <span class="timeline-skill-pill">React</span>
                                    <span class="timeline-skill-pill">Node.js</span>
                                    <span class="timeline-skill-pill">Digital Marketing</span>
                                    <span class="timeline-skill-pill">UI/UX</span>
                                </div>
                            </div>

                            <!-- Exp 4: Professional Internship -->
                            <div class="timeline-card">
                                <div class="timeline-badge">2022 – 2023</div>
                                <h4 class="role-title">Web Developer Intern</h4>
                                <h5 class="company-name">Professional Internship</h5>
                                <p class="role-desc">Gained practical experience in web development, frontend implementation, backend concepts, and real-world development workflows.</p>
                                <div class="timeline-skills-list">
                                    <span class="timeline-skill-pill">HTML5</span>
                                    <span class="timeline-skill-pill">CSS3</span>
                                    <span class="timeline-skill-pill">JavaScript</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Column 2: Education & Academic Journey (WITH credentials & image previews) -->
                    <div class="journey-column">
                        <div class="journey-heading">
                            <i class="fa-solid fa-graduation-cap"></i>
                            <h3>Education & Academic Credentials</h3>
                        </div>

                        <div class="timeline-items">
                            <!-- Edu 1: University of Asia Pacific -->
                            <div class="timeline-card">
                                <div class="timeline-badge">2019 – 2023</div>
                                <h4 class="role-title">Bachelor's in Computer Science</h4>
                                <h5 class="company-name">University of Asia Pacific &bull; Academic Degree</h5>
                                <p class="role-desc">Academic studies focused on computer science, software engineering, databases, programming, algorithms, and web development.</p>
                                
                                <div class="timeline-cert-preview" onclick="openCertificateModal(1)">
                                    <img src="<?php echo esc_url($c_uap); ?>" alt="UAP Award" class="timeline-cert-thumb">
                                    <div class="timeline-cert-info">
                                        <span class="timeline-cert-title">Dean's (3x) & VC Award Distinction</span>
                                        <span class="timeline-cert-action"><i class="fa-solid fa-expand"></i> Click to view award certificate</span>
                                    </div>
                                </div>
                            </div>

                            <!-- Edu 2: Pearson BTEC HND -->
                            <div class="timeline-card">
                                <div class="timeline-badge">2024 – 2026</div>
                                <h4 class="role-title">Pearson BTEC Level 5 Higher National Diploma (HND) in Digital Technologies</h4>
                                <h5 class="company-name">Global Business Studies FZ LLC &bull; Dubai, United Arab Emirates</h5>
                                <p class="role-desc">Specialized in AI Solutions and Applications, academic studies in programming, cloud fundamentals, professional practice in the digital economy, and innovation.</p>
                                
                                <div class="timeline-cert-preview" onclick="openCertificateModal(4)">
                                    <img src="<?php echo esc_url($c_gbs); ?>" alt="GBS BTEC HND Certificate" class="timeline-cert-thumb">
                                    <div class="timeline-cert-info">
                                        <span class="timeline-cert-title">Pearson BTEC Level 5 HND Certificate</span>
                                        <span class="timeline-cert-action"><i class="fa-solid fa-expand"></i> Click to view diploma credential</span>
                                    </div>
                                </div>
                            </div>

                            <!-- Edu 3: Phitron -->
                            <div class="timeline-card">
                                <div class="timeline-badge">Completed (Fall 2024)</div>
                                <h4 class="role-title">Fundamentals of Computer Science Engineering</h4>
                                <h5 class="company-name">Phitron.io &bull; Distinction CGPA 3.67</h5>
                                <p class="role-desc">Intensive practical training in programming, problem solving, data structures, algorithms, and core software engineering concepts.</p>
                                
                                <div class="timeline-cert-preview" onclick="openCertificateModal(2)">
                                    <img src="<?php echo esc_url($c_phitron); ?>" alt="Phitron Certificate" class="timeline-cert-thumb">
                                    <div class="timeline-cert-info">
                                        <span class="timeline-cert-title">CSE Fundamentals Certificate (CGPA 3.67)</span>
                                        <span class="timeline-cert-action"><i class="fa-solid fa-expand"></i> Click to view verified certificate</span>
                                    </div>
                                </div>
                            </div>

                            <!-- Edu 4: AI & Modern Web Self Learning -->
                            <div class="timeline-card">
                                <div class="timeline-badge">Ongoing</div>
                                <h4 class="role-title">AI / ML & Modern Web Technologies</h4>
                                <h5 class="company-name">Self-Directed Learning & Research</h5>
                                <p class="role-desc">Continuously exploring AI/ML, AI agent architectures, automation pipelines, RESTful APIs, and modern web application patterns.</p>
                                
                                <div class="timeline-cert-preview" onclick="openCertificateModal(5)">
                                    <img src="<?php echo esc_url($c_claude); ?>" alt="Claude 101 Certificate" class="timeline-cert-thumb">
                                    <div class="timeline-cert-info">
                                        <span class="timeline-cert-title">Anthropic Claude 101 AI Certification</span>
                                        <span class="timeline-cert-action"><i class="fa-solid fa-expand"></i> Click to view official certificate</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Brands & Technology Partners Marquee -->
        <section class="partners-marquee-section">
            <div class="container">
                <p class="marquee-title">CORE TECHNOLOGIES & TOOLS I WORK WITH</p>
            </div>
            <div class="marquee-track">
                <div class="marquee-content">
                    <span class="marquee-item"><i class="devicon-python-plain colored"></i> PYTHON</span>
                    <span class="marquee-item"><i class="devicon-django-plain colored"></i> DJANGO</span>
                    <span class="marquee-item"><i class="devicon-react-original colored"></i> REACT</span>
                    <span class="marquee-item"><i class="devicon-nextjs-plain"></i> NEXT.JS</span>
                    <span class="marquee-item"><i class="devicon-fastapi-plain colored"></i> FASTAPI</span>
                    <span class="marquee-item"><i class="devicon-postgresql-plain colored"></i> POSTGRESQL</span>
                    <span class="marquee-item"><i class="devicon-javascript-plain colored"></i> JAVASCRIPT</span>
                    <span class="marquee-item"><i class="devicon-typescript-plain colored"></i> TYPESCRIPT</span>
                    <span class="marquee-item"><i class="devicon-docker-plain colored"></i> DOCKER</span>
                    <span class="marquee-item"><i class="fa-brands fa-wordpress"></i> WORDPRESS</span>
                </div>
                <div class="marquee-content" aria-hidden="true">
                    <span class="marquee-item"><i class="devicon-python-plain colored"></i> PYTHON</span>
                    <span class="marquee-item"><i class="devicon-django-plain colored"></i> DJANGO</span>
                    <span class="marquee-item"><i class="devicon-react-original colored"></i> REACT</span>
                    <span class="marquee-item"><i class="devicon-nextjs-plain"></i> NEXT.JS</span>
                    <span class="marquee-item"><i class="devicon-fastapi-plain colored"></i> FASTAPI</span>
                    <span class="marquee-item"><i class="devicon-postgresql-plain colored"></i> POSTGRESQL</span>
                    <span class="marquee-item"><i class="devicon-javascript-plain colored"></i> JAVASCRIPT</span>
                    <span class="marquee-item"><i class="devicon-typescript-plain colored"></i> TYPESCRIPT</span>
                    <span class="marquee-item"><i class="devicon-docker-plain colored"></i> DOCKER</span>
                    <span class="marquee-item"><i class="fa-brands fa-wordpress"></i> WORDPRESS</span>
                </div>
            </div>
        </section>

        <!-- Latest Portfolio / Projects Showcase Section -->
        <section id="portfolio" class="portfolio-section section-gap">
            <div class="container">
                <div class="section-header text-center">
                    <span class="section-tag">FEATURED CREATIONS</span>
                    <h2 class="section-title">Recent Selected Projects</h2>
                    <p class="section-subtitle">Real-world production applications built with clean architecture, scalability, and modern UI design.</p>
                </div>

                <!-- Portfolio Filter Tabs -->
                <div class="portfolio-filter-tabs">
                    <button class="filter-btn active" data-filter="all">All Projects</button>
                    <button class="filter-btn" data-filter="django">Django & Backend</button>
                    <button class="filter-btn" data-filter="react">React & Next.js</button>
                    <button class="filter-btn" data-filter="fullstack">Full-Stack</button>
                </div>

                <!-- Projects Grid -->
                <div class="portfolio-grid">
                    <!-- Project 1: SnapBook -->
                    <div class="portfolio-card" data-category="django react fullstack" onclick="openProjectModal(1)">
                        <div class="project-img-box">
                            <img src="<?php echo esc_url($p1_url); ?>" alt="SnapBook Social Media Platform" class="project-img">
                            <div class="project-overlay">
                                <span class="view-btn"><i class="fa-solid fa-magnifying-glass-plus"></i> View Case Study</span>
                            </div>
                        </div>
                        <div class="project-info">
                            <div class="info-meta">
                                <span class="project-cat">Django & React Full-Stack</span>
                                <h3 class="project-title">SnapBook - Social Platform</h3>
                                <p class="project-desc">A modern social media platform for sharing photos, stories, and connecting with friends through a clean digital experience.</p>
                            </div>
                            <div class="arrow-btn-wrap">
                                <div class="arrow-btn-inner">
                                    <i class="fa-solid fa-arrow-up-right arrow-1"></i>
                                    <i class="fa-solid fa-arrow-up-right arrow-2"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Project 2: Review Platform -->
                    <div class="portfolio-card" data-category="fastapi react fullstack" onclick="openProjectModal(2)">
                        <div class="project-img-box">
                            <img src="<?php echo esc_url($p2_url); ?>" alt="Review Platform" class="project-img">
                            <div class="project-overlay">
                                <span class="view-btn"><i class="fa-solid fa-magnifying-glass-plus"></i> View Case Study</span>
                            </div>
                        </div>
                        <div class="project-info">
                            <div class="info-meta">
                                <span class="project-cat">FastAPI & Next.js</span>
                                <h3 class="project-title">Product Review Platform</h3>
                                <p class="project-desc">A platform for discovering products, comparing ratings, and sharing verified customer experiences with sub-second response times.</p>
                            </div>
                            <div class="arrow-btn-wrap">
                                <div class="arrow-btn-inner">
                                    <i class="fa-solid fa-arrow-up-right arrow-1"></i>
                                    <i class="fa-solid fa-arrow-up-right arrow-2"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Project 3: Eventify -->
                    <div class="portfolio-card" data-category="django fullstack" onclick="openProjectModal(3)">
                        <div class="project-img-box">
                            <img src="<?php echo esc_url($p3_url); ?>" alt="Eventify Management Platform" class="project-img">
                            <div class="project-overlay">
                                <span class="view-btn"><i class="fa-solid fa-magnifying-glass-plus"></i> View Case Study</span>
                            </div>
                        </div>
                        <div class="project-info">
                            <div class="info-meta">
                                <span class="project-cat">Django & PostgreSQL</span>
                                <h3 class="project-title">Eventify - Event Hub</h3>
                                <p class="project-desc">An event management platform for creating, organizing, and managing events with streamlined attendee experiences.</p>
                            </div>
                            <div class="arrow-btn-wrap">
                                <div class="arrow-btn-inner">
                                    <i class="fa-solid fa-arrow-up-right arrow-1"></i>
                                    <i class="fa-solid fa-arrow-up-right arrow-2"></i>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Project 4: CPL Construction Services -->
                    <div class="portfolio-card" data-category="react fullstack" onclick="openProjectModal(4)">
                        <div class="project-img-box">
                            <img src="<?php echo esc_url($p4_url); ?>" alt="CPL Construction Services" class="project-img">
                            <div class="project-overlay">
                                <span class="view-btn"><i class="fa-solid fa-magnifying-glass-plus"></i> View Case Study</span>
                            </div>
                        </div>
                        <div class="project-info">
                            <div class="info-meta">
                                <span class="project-cat">Next.js & TypeScript</span>
                                <h3 class="project-title">CPL Construction Platform</h3>
                                <p class="project-desc">A construction service platform providing building services, machinery sales & rentals, and quality materials across Bangladesh.</p>
                            </div>
                            <div class="arrow-btn-wrap">
                                <div class="arrow-btn-inner">
                                    <i class="fa-solid fa-arrow-up-right arrow-1"></i>
                                    <i class="fa-solid fa-arrow-up-right arrow-2"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Achievements & Certifications Section (WITH images & interactive lightbox) -->
        <section id="achievements" class="achievements-section section-gap">
            <div class="container">
                <div class="section-header text-center">
                    <span class="section-tag">HONORS & CREDENTIALS</span>
                    <h2 class="section-title">Achievements & Certifications</h2>
                    <p class="section-subtitle">Verified academic awards, professional certificates, and technical achievements.</p>
                </div>

                <!-- Achievements Filter Tabs -->
                <div class="achievements-filter-tabs">
                    <button class="filter-btn active" data-filter="all">All Credentials</button>
                    <button class="filter-btn" data-filter="academic">Academic Awards</button>
                    <button class="filter-btn" data-filter="professional">Professional & Digital</button>
                    <button class="filter-btn" data-filter="ai">AI & Training</button>
                </div>

                <!-- Achievements Grid -->
                <div class="achievements-grid">
                    <!-- Cert 1: UAP Dean's & VC Awards -->
                    <div class="achievement-card" data-category="academic">
                        <div class="achievement-img-box" onclick="openCertificateModal(1)">
                            <img src="<?php echo esc_url($c_uap); ?>" alt="University of Asia Pacific Dean's & VC Award" class="achievement-img">
                            <div class="achievement-overlay">
                                <span class="achievement-view-btn"><i class="fa-solid fa-magnifying-glass-plus"></i> View Certificate</span>
                            </div>
                        </div>
                        <div class="achievement-body">
                            <span class="achievement-badge">Academic Excellence</span>
                            <h3 class="achievement-title">Dean's Awards (3x) & Vice Chancellor Award (1x)</h3>
                            <div class="achievement-meta">
                                <span class="achievement-org">University of Asia Pacific</span>
                                <span class="achievement-date">2019 – 2024</span>
                            </div>
                            <p class="achievement-desc">Received academic excellence awards for maintaining high CGPA across multiple semesters in Computer Science & Engineering.</p>
                            <div class="achievement-actions">
                                <button type="button" class="achievement-btn-link" onclick="openCertificateModal(1)">
                                    <span>Expand Certificate</span>
                                    <i class="fa-solid fa-arrow-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Cert 2: Phitron -->
                    <div class="achievement-card" data-category="academic ai">
                        <div class="achievement-img-box" onclick="openCertificateModal(2)">
                            <img src="<?php echo esc_url($c_phitron); ?>" alt="Phitron CSE Fundamentals Certificate" class="achievement-img">
                            <div class="achievement-overlay">
                                <span class="achievement-view-btn"><i class="fa-solid fa-magnifying-glass-plus"></i> View Certificate</span>
                            </div>
                        </div>
                        <div class="achievement-body">
                            <span class="achievement-badge">Computer Science Distinction</span>
                            <h3 class="achievement-title">CSE Fundamentals With Phitron</h3>
                            <div class="achievement-meta">
                                <span class="achievement-org">Phitron.io</span>
                                <span class="achievement-date">Fall 2024</span>
                            </div>
                            <p class="achievement-desc">Successfully completed CSE Fundamentals With Phitron with a distinction CGPA of 3.67, mastering algorithms and data structures.</p>
                            <div class="achievement-actions">
                                <button type="button" class="achievement-btn-link" onclick="openCertificateModal(2)">
                                    <span>Expand Certificate</span>
                                    <i class="fa-solid fa-arrow-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Cert 3: Urban Academy -->
                    <div class="achievement-card" data-category="professional">
                        <div class="achievement-img-box" onclick="openCertificateModal(3)">
                            <img src="<?php echo esc_url($c_ua); ?>" alt="Urban Academy Digital Marketing Certificate" class="achievement-img">
                            <div class="achievement-overlay">
                                <span class="achievement-view-btn"><i class="fa-solid fa-magnifying-glass-plus"></i> View Certificate</span>
                            </div>
                        </div>
                        <div class="achievement-body">
                            <span class="achievement-badge">Professional Certification</span>
                            <h3 class="achievement-title">The Science of Digital Marketing</h3>
                            <div class="achievement-meta">
                                <span class="achievement-org">Urban Academy</span>
                                <span class="achievement-date">July 2026</span>
                            </div>
                            <p class="achievement-desc">Completed the 16-week programme covering marketing strategy, copywriting, Meta advertising, AI chatbot integration, and campaigns.</p>
                            <div class="achievement-actions">
                                <button type="button" class="achievement-btn-link" onclick="openCertificateModal(3)">
                                    <span>Expand Certificate</span>
                                    <i class="fa-solid fa-arrow-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Cert 4: GBS Pearson BTEC HND -->
                    <div class="achievement-card" data-category="academic professional">
                        <div class="achievement-img-box" onclick="openCertificateModal(4)">
                            <img src="<?php echo esc_url($c_gbs); ?>" alt="Pearson BTEC Level 5 HND Certificate" class="achievement-img">
                            <div class="achievement-overlay">
                                <span class="achievement-view-btn"><i class="fa-solid fa-magnifying-glass-plus"></i> View Certificate</span>
                            </div>
                        </div>
                        <div class="achievement-body">
                            <span class="achievement-badge">Higher National Diploma</span>
                            <h3 class="achievement-title">Pearson BTEC Level 5 HND in Digital Technologies</h3>
                            <div class="achievement-meta">
                                <span class="achievement-org">Global Business Studies, Dubai</span>
                                <span class="achievement-date">2024 – 2026</span>
                            </div>
                            <p class="achievement-desc">Completed Level 5 HND in Digital Technologies (AI Solutions and Applications), cloud fundamentals, and digital transformation.</p>
                            <div class="achievement-actions">
                                <button type="button" class="achievement-btn-link" onclick="openCertificateModal(4)">
                                    <span>Expand Certificate</span>
                                    <i class="fa-solid fa-arrow-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Cert 5: Anthropic Claude 101 -->
                    <div class="achievement-card" data-category="ai professional">
                        <div class="achievement-img-box" onclick="openCertificateModal(5)">
                            <img src="<?php echo esc_url($c_claude); ?>" alt="Anthropic Claude 101 Certificate" class="achievement-img">
                            <div class="achievement-overlay">
                                <span class="achievement-view-btn"><i class="fa-solid fa-magnifying-glass-plus"></i> View Certificate</span>
                            </div>
                        </div>
                        <div class="achievement-body">
                            <span class="achievement-badge">AI & LLM Certification</span>
                            <h3 class="achievement-title">Claude 101 Certification</h3>
                            <div class="achievement-meta">
                                <span class="achievement-org">Anthropic</span>
                                <span class="achievement-date">2026</span>
                            </div>
                            <p class="achievement-desc">Successfully completed official certification in Claude models, advanced prompt engineering, context management, and AI app development.</p>
                            <div class="achievement-actions">
                                <button type="button" class="achievement-btn-link" onclick="openCertificateModal(5)">
                                    <span>Expand Certificate</span>
                                    <i class="fa-solid fa-arrow-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Cert 6: Food Safety -->
                    <div class="achievement-card" data-category="professional ai">
                        <div class="achievement-img-box" onclick="openCertificateModal(6)">
                            <img src="<?php echo esc_url($c_food); ?>" alt="Basic Food Safety Training Certificate" class="achievement-img">
                            <div class="achievement-overlay">
                                <span class="achievement-view-btn"><i class="fa-solid fa-magnifying-glass-plus"></i> View Certificate</span>
                            </div>
                        </div>
                        <div class="achievement-body">
                            <span class="achievement-badge">Standards & Safety</span>
                            <h3 class="achievement-title">Basic Food Safety – Food Service Training</h3>
                            <div class="achievement-meta">
                                <span class="achievement-org">Zigma Quality Training</span>
                                <span class="achievement-date">September 2024</span>
                            </div>
                            <p class="achievement-desc">Completed certified food service training programme designed in alignment with international safety and quality standards.</p>
                            <div class="achievement-actions">
                                <button type="button" class="achievement-btn-link" onclick="openCertificateModal(6)">
                                    <span>Expand Certificate</span>
                                    <i class="fa-solid fa-arrow-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Dynamic Interactive Services Widget -->
        <section class="interactive-widget-section section-gap">
            <div class="container">
                <div class="section-header text-center">
                    <span class="section-tag">CORE COMPETENCIES</span>
                    <h2 class="section-title">Elevated Solutions, Personalized Quality</h2>
                    <p class="section-subtitle">Hover or tap on any service area to explore our core execution strengths.</p>
                </div>

                <div class="interactive-slider-widget" id="interactive-widget">
                    <div class="widget-item active" data-index="0">
                        <div class="widget-icon"><i class="fa-solid fa-compass-drafting"></i></div>
                        <div class="widget-head">
                            <h3 class="widget-title">Backend Architecture & DRF</h3>
                            <span class="widget-badge">Django Specialist</span>
                        </div>
                        <p class="widget-text">Drafting decoupled API endpoints, structured ORM models, and database migrations that resist technical debt and scale painlessly.</p>
                        <a href="#contact" class="widget-cta">
                            <span>Get A Consultation</span>
                            <i class="fa-solid fa-chevron-right"></i>
                        </a>
                    </div>

                    <div class="widget-item" data-index="1">
                        <div class="widget-icon"><i class="fa-solid fa-wand-magic-sparkles"></i></div>
                        <div class="widget-head">
                            <h3 class="widget-title">Modern React & Next.js</h3>
                            <span class="widget-badge">Frontend Engineering</span>
                        </div>
                        <p class="widget-text">Building fast, reactive user interfaces with modern React, Tailwind CSS, TypeScript, and seamless REST API integrations.</p>
                        <a href="#contact" class="widget-cta">
                            <span>Get A Consultation</span>
                            <i class="fa-solid fa-chevron-right"></i>
                        </a>
                    </div>

                    <div class="widget-item" data-index="2">
                        <div class="widget-icon"><i class="fa-solid fa-bullhorn"></i></div>
                        <div class="widget-head">
                            <h3 class="widget-title">Digital Marketing & Growth</h3>
                            <span class="widget-badge">Meta & Google Ads</span>
                        </div>
                        <p class="widget-text">Combining technical web expertise with high-converting digital advertising, content marketing, and WordPress CMS administration.</p>
                        <a href="#contact" class="widget-cta">
                            <span>Get A Consultation</span>
                            <i class="fa-solid fa-chevron-right"></i>
                        </a>
                    </div>

                    <!-- Sliding Active Background Pill Indicator -->
                    <div class="sliding-active-bg" id="sliding-bg"></div>
                </div>
            </div>
        </section>

        <!-- Client Testimonials Slider Section -->
        <section id="testimonials" class="testimonials-section section-gap">
            <div class="container">
                <div class="section-header text-center">
                    <span class="section-tag">ENDORSEMENTS</span>
                    <h2 class="section-title">What Collaborators & Clients Say</h2>
                    <p class="section-subtitle">Real feedback from founders, product directors, and engineering peers.</p>
                </div>

                <div class="testimonials-carousel-wrapper">
                    <div class="testimonials-slider" id="testimonial-slider">
                        <!-- Slide 1 -->
                        <div class="testimonial-slide active">
                            <div class="testimonial-card glass-panel">
                                <div class="quote-icon"><i class="fa-solid fa-quote-left"></i></div>
                                <div class="star-rating">
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                </div>
                                <p class="testimonial-quote">
                                    "Siam is a skilled full-stack developer who understands both backend stability with Django and responsive UI with React. His dedication to clean code, punctual delivery, and thoughtful problem-solving makes him a true asset to any project."
                                </p>
                                <div class="client-meta">
                                    <div class="client-info">
                                        <h4 class="client-name">Engineering Lead</h4>
                                        <p class="client-role">Software & Solutions Team</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Slide 2 -->
                        <div class="testimonial-slide">
                            <div class="testimonial-card glass-panel">
                                <div class="quote-icon"><i class="fa-solid fa-quote-left"></i></div>
                                <div class="star-rating">
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                </div>
                                <p class="testimonial-quote">
                                    "Working with Siam was fantastic. He combines technical development with practical digital marketing acumen. He communicated clearly, resolved complex bugs quickly, and delivered our web application ahead of schedule."
                                </p>
                                <div class="client-meta">
                                    <div class="client-info">
                                        <h4 class="client-name">Digital Growth Director</h4>
                                        <p class="client-role">International Business Partner</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Slide 3 -->
                        <div class="testimonial-slide">
                            <div class="testimonial-card glass-panel">
                                <div class="quote-icon"><i class="fa-solid fa-quote-left"></i></div>
                                <div class="star-rating">
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                    <i class="fa-solid fa-star"></i>
                                </div>
                                <p class="testimonial-quote">
                                    "Siam's approach to API structure and database relations is exemplary. He is enthusiastic, continuously learning the latest in AI and web frameworks, and always delivers polished, maintainable code."
                                </p>
                                <div class="client-meta">
                                    <div class="client-info">
                                        <h4 class="client-name">Project Manager</h4>
                                        <p class="client-role">Web & Tech Agency</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Carousel Controls -->
                    <div class="carousel-controls">
                        <button id="slider-prev" class="slider-arrow-btn" aria-label="Previous testimonial">
                            <i class="fa-solid fa-arrow-left"></i>
                        </button>
                        <div class="slider-dots" id="slider-dots">
                            <span class="dot active" data-slide="0"></span>
                            <span class="dot" data-slide="1"></span>
                            <span class="dot" data-slide="2"></span>
                        </div>
                        <button id="slider-next" class="slider-arrow-btn" aria-label="Next testimonial">
                            <i class="fa-solid fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </section>

        <!-- Tech Insights / Blog Section -->
        <section id="blog" class="blog-section section-gap">
            <div class="container">
                <div class="section-header text-center">
                    <span class="section-tag">ENGINEERING WRITINGS</span>
                    <h2 class="section-title">Latest Articles & Insights</h2>
                    <p class="section-subtitle">Practical deep-dives into modern backend architecture, full-stack development, and AI tools.</p>
                </div>

                <div class="blog-grid">
                    <!-- Post 1 -->
                    <article class="blog-card" onclick="openBlogModal(1)">
                        <div class="blog-img-box">
                            <img src="<?php echo esc_url($b1_url); ?>" alt="Django REST Framework Best Practices" class="blog-img">
                            <div class="blog-tag">Backend Architecture</div>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <span><i class="fa-regular fa-user"></i> <?php echo esc_html($dev_name); ?></span>
                                <span><i class="fa-regular fa-clock"></i> 6 min read</span>
                                <span><i class="fa-regular fa-calendar"></i> Oct 2026</span>
                            </div>
                            <h3 class="blog-title">Building Scalable REST APIs with Django & Django REST Framework</h3>
                            <p class="blog-excerpt">Practical strategies for structuring serializers, query prefetching, token rotation, and robust authentication.</p>
                            <a href="javascript:void(0)" class="read-post-link">
                                <span>Read Full Article</span>
                                <i class="fa-solid fa-arrow-right"></i>
                            </a>
                        </div>
                    </article>

                    <!-- Post 2 -->
                    <article class="blog-card" onclick="openBlogModal(2)">
                        <div class="blog-img-box">
                            <img src="<?php echo esc_url($b2_url); ?>" alt="React and Next.js" class="blog-img">
                            <div class="blog-tag">Full-Stack</div>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <span><i class="fa-regular fa-user"></i> <?php echo esc_html($dev_name); ?></span>
                                <span><i class="fa-regular fa-clock"></i> 7 min read</span>
                                <span><i class="fa-regular fa-calendar"></i> Sep 2026</span>
                            </div>
                            <h3 class="blog-title">Bridging Modern React & Next.js with Scalable Backend Systems</h3>
                            <p class="blog-excerpt">Unlocking asynchronous state synchronization, optimistic UI updates, and type safety between backends and frontends.</p>
                            <a href="javascript:void(0)" class="read-post-link">
                                <span>Read Full Article</span>
                                <i class="fa-solid fa-arrow-right"></i>
                            </a>
                        </div>
                    </article>

                    <!-- Post 3 -->
                    <article class="blog-card" onclick="openBlogModal(3)">
                        <div class="blog-img-box">
                            <img src="<?php echo esc_url($b3_url); ?>" alt="AI Agents and Automation" class="blog-img">
                            <div class="blog-tag">AI & Innovation</div>
                        </div>
                        <div class="blog-content">
                            <div class="blog-meta">
                                <span><i class="fa-regular fa-user"></i> <?php echo esc_html($dev_name); ?></span>
                                <span><i class="fa-regular fa-clock"></i> 5 min read</span>
                                <span><i class="fa-regular fa-calendar"></i> Aug 2026</span>
                            </div>
                            <h3 class="blog-title">How Developers Can Leverage AI Agents and Modern Automation</h3>
                            <p class="blog-excerpt">Exploring LLM system prompts, structured tool calls, and autonomous workflows to streamline software development.</p>
                            <a href="javascript:void(0)" class="read-post-link">
                                <span>Read Full Article</span>
                                <i class="fa-solid fa-arrow-right"></i>
                            </a>
                        </div>
                    </article>
                </div>
            </div>
        </section>

        <!-- Contact & Appointment Section -->
        <section id="contact" class="contact-section section-gap">
            <div class="container">
                <div class="contact-panel glass-panel">
                    <div class="contact-grid">
                        <!-- Contact Left Info -->
                        <div class="contact-info-col">
                            <span class="section-tag">LET'S CONNECT</span>
                            <h2 class="contact-title">Let's Build Something <br><span class="gradient-text">Exceptional</span></h2>
                            <p class="contact-desc">
                                Have an upcoming project in mind, need a Django backend or React full-stack developer, or looking to scale your business with modern web solutions? I'm always open to discussing new high-impact opportunities.
                            </p>

                            <div class="contact-details-list">
                                <div class="detail-item">
                                    <div class="detail-icon"><i class="fa-solid fa-envelope"></i></div>
                                    <div class="detail-texts">
                                        <span class="detail-label">Direct Email</span>
                                        <a href="mailto:<?php echo esc_attr($dev_email); ?>" class="detail-value"><?php echo esc_html($dev_email); ?></a>
                                    </div>
                                </div>

                                <div class="detail-item">
                                    <div class="detail-icon"><i class="fa-solid fa-location-dot"></i></div>
                                    <div class="detail-texts">
                                        <span class="detail-label">Current Base</span>
                                        <span class="detail-value">Bangladesh &bull; Global Remote (UTC+6)</span>
                                    </div>
                                </div>

                                <div class="detail-item">
                                    <div class="detail-icon"><i class="fa-solid fa-file-pdf"></i></div>
                                    <div class="detail-texts">
                                        <span class="detail-label">Curriculum Vitae</span>
                                        <a href="<?php echo esc_url($resume_url); ?>" target="_blank" class="detail-value">View & Download Resume</a>
                                    </div>
                                </div>
                            </div>

                            <div class="availability-badge">
                                <span class="pulse-dot"></span>
                                <span>Available for Remote Roles & High-Impact Projects</span>
                            </div>
                        </div>

                        <!-- Contact Right Form -->
                        <div class="contact-form-col">
                            <form id="contact-form" class="styled-form" novalidate>
                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="contact-name">Your Full Name *</label>
                                        <input type="text" id="contact-name" name="name" class="form-control" placeholder="e.g. John Doe" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="contact-email">Email Address *</label>
                                        <input type="email" id="contact-email" name="email" class="form-control" placeholder="john@company.com" required>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group">
                                        <label for="contact-phone">Phone / WhatsApp</label>
                                        <input type="tel" id="contact-phone" name="phone" class="form-control" placeholder="+880 1xxx-xxxxxx">
                                    </div>
                                    <div class="form-group">
                                        <label for="contact-subject">Project Category</label>
                                        <select id="contact-subject" name="subject" class="form-control">
                                            <option value="Django Backend Development">Django Backend Development</option>
                                            <option value="Full-Stack Web App">Full-Stack Web Application (Django + React)</option>
                                            <option value="Next.js & Frontend Project">Next.js & Modern Frontend</option>
                                            <option value="Digital Marketing & WordPress">Digital Marketing & WordPress Growth</option>
                                            <option value="AI Agent & Automation">AI Agent & Automation Integration</option>
                                            <option value="Other Project">Other Opportunity / Consultation</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="contact-message">Project Vision & Message *</label>
                                    <textarea id="contact-message" name="message" rows="5" class="form-control" placeholder="Tell me about your project goals, tech stack, and timeline..." required></textarea>
                                </div>

                                <button type="submit" id="submit-btn" class="btn btn-primary btn-round btn-full btn-icon-flip">
                                    <span class="btn-text">Send Message Now</span>
                                    <span class="icon-wrap">
                                        <i class="fa-solid fa-paper-plane icon-main"></i>
                                        <i class="fa-solid fa-paper-plane icon-alt"></i>
                                    </span>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="site-footer">
        <div class="container">
            <div class="footer-top">
                <div class="footer-brand-col">
                    <a href="#" class="brand-logo">
                        <img src="<?php echo esc_url($logo_url); ?>" alt="Siam Logo" class="brand-logo-img">
                        <span>Siam<span class="logo-dot">.</span>dev</span>
                    </a>
                    <p class="footer-bio">
                        Engineering scalable web applications, secure Django backends, and responsive React interfaces with modern technologies and clean architecture.
                    </p>
                    <div class="footer-socials">
                        <a href="https://github.com/siamhossain7722" target="_blank" aria-label="GitHub"><i class="fa-brands fa-github"></i></a>
                        <a href="https://www.linkedin.com/in/siamhossain7722/" target="_blank" aria-label="LinkedIn"><i class="fa-brands fa-linkedin-in"></i></a>
                        <a href="https://www.facebook.com/siamhossain7722/" target="_blank" aria-label="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    </div>
                </div>

                <div class="footer-links-col">
                    <h4 class="footer-heading">Navigation</h4>
                    <ul>
                        <li><a href="#home">Home</a></li>
                        <li><a href="#about">About Me</a></li>
                        <li><a href="#services">Services</a></li>
                        <li><a href="#skills">Skills & Stack</a></li>
                        <li><a href="#experience">Experience & Education</a></li>
                        <li><a href="#portfolio">Projects</a></li>
                        <li><a href="#achievements">Achievements</a></li>
                        <li><a href="#contact">Contact</a></li>
                    </ul>
                </div>

                <div class="footer-links-col">
                    <h4 class="footer-heading">Core Skills</h4>
                    <ul>
                        <li><a href="#skills">Django & DRF APIs</a></li>
                        <li><a href="#skills">React & Next.js</a></li>
                        <li><a href="#skills">Python & FastAPI</a></li>
                        <li><a href="#skills">PostgreSQL & Databases</a></li>
                        <li><a href="#skills">Digital Marketing & WordPress</a></li>
                    </ul>
                </div>

                <div class="footer-newsletter-col">
                    <h4 class="footer-heading">Curriculum Vitae</h4>
                    <p class="newsletter-desc">Download my full professional resume for detailed background, education, and project portfolio.</p>
                    <a href="<?php echo esc_url($resume_url); ?>" target="_blank" class="btn btn-secondary btn-round btn-full" style="margin-top: 10px;">
                        <i class="fa-solid fa-file-pdf"></i>
                        <span>Download Resume (PDF)</span>
                    </a>
                </div>
            </div>

            <div class="footer-bottom">
                <p>&copy; 2026 <?php echo esc_html($dev_name); ?>. Crafted with HTML5, CSS3 & JavaScript. All rights reserved.</p>
                <div class="footer-bottom-links">
                    <a href="#privacy">Privacy Policy</a>
                    <a href="#terms">Terms of Service</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <button id="back-to-top" class="back-to-top" aria-label="Back to top">
        <svg class="progress-ring" width="46" height="46">
            <circle class="progress-ring-circle" stroke="rgba(255, 1, 79, 0.8)" stroke-width="3" fill="transparent" r="20" cx="23" cy="23"/>
        </svg>
        <i class="fa-solid fa-arrow-up"></i>
    </button>

    <!-- Modal Dialog for Projects / Services / Certificates / Blog -->
    <div id="info-modal" class="custom-modal">
        <div class="modal-backdrop" onclick="closeModal()"></div>
        <div class="modal-dialog glass-panel">
            <button class="modal-close-btn" onclick="closeModal()"><i class="fa-solid fa-xmark"></i></button>
            <div id="modal-body-content" class="modal-content-area">
                <!-- Dynamically populated via JS -->
            </div>
        </div>
    </div>

    <?php wp_footer(); ?>
</body>
</html>
